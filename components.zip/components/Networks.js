import { View, Text } from 'react-native'
import React from 'react'

const Networks = () => {
    return (
        <View>
            <Text>Networks</Text>
        </View>
    )
}

export default Networks